import tkinter as tk
import numpy as np
import matplotlib
from tkinter import Canvas, Label, Button, Entry, Checkbutton, Text
from PIL import ImageTk, Image
from sympy import sin, cos, sympify, lambdify
matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk


class RungeKuttaApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.geometry('1000x500')
        self.title('Método de Runge-Kutta')
        self.canvas = Canvas(self, width=1000, height=500)
        self.canvas.place(x=0, y=0)
        img = Image.open("fondo.jpg")
        img = ImageTk.PhotoImage(img)
        self.canvas.create_image(500, 250, anchor="center", image=img)
        #------------------------------------------------Textos---------------------------------------------------------
        self.canvas.create_text(50, 23, text="Runge-Kutta", anchor="nw", font=("Arial", 25, "bold"), fill='#fff')
        self.canvas.create_text(85,95,text="Ingrese la ecuación:", anchor="nw", font=("Arial", 10, "bold"))
        self.canvas.create_text(50,115,text="Y' = ", anchor="nw", font=("Arial", 10, "bold"))
        self.canvas.create_text(805,95,text="Ingrese los valores Iniciales:", anchor="nw", font=("Arial", 10, "bold"))
        self.canvas.create_text(815,120,text="Xo =", anchor="nw", font=("Arial", 10, "bold"))
        self.canvas.create_text(815,145,text="Yo =", anchor="nw", font=("Arial", 10, "bold"))
        self.canvas.create_text(825,165,text="Valor a Calcular y(x)", anchor="nw", font=("Arial", 10, "bold"))
        self.canvas.create_text(825,190,text="X =", anchor="nw", font=("Arial", 10, "bold"))
        self.canvas.create_text(815,215,text="Aproximación a mostrar:", anchor="nw", font=("Arial", 10, "bold"))
        #-------------------------------------------------Entrys-------------------------------------------------------
        self.tbx1 = Entry(self) #-------Ingreso de Ecuacion-------
        self.tbx1.place(x=85,y=115)
        self.tbx2 = Entry(self)#----------------X_o---------------
        self.tbx2.place(x=850,y=118)
        self.tbx3 = Entry(self)#----------------Y_o---------------
        self.tbx3.place(x=850,y=143)
        self.tbx4 = Entry(self)#-----------------X----------------
        self.tbx4.place(x=850,y=187)
        self.txt = Text(self,width=45,height=20)
        self.txt.place(x=45,y=145)
        #------------------------------------------------Graficador-----------------------------------------------------
        self.cv2 = Canvas(self, width=300, height=300)
        self.cv2.place(x=450, y=145)
        #-----------------------------------------------CheckButtons----------------------------------------------------
        self.cbt1 = Checkbutton(self, text="RK1",background="#EB5C18")
        self.cbt1.place(x=825,y=230)
        self.cbt2 = Checkbutton(self, text="RK2",background="#EB5C18")
        self.cbt2.place(x=825,y=250)
        self.cbt3 = Checkbutton(self, text="RK2",background="#EB5C18")
        self.cbt3.place(x=825,y=270)
        self.b1 = Button(self, text="Calcular", width=10)
        self.b1.place(x=850,y=300)
        self.b2 = Button(self, text="Cerrar", width=10)
        self.b2.place(x=850,y=330)
        #--------------------------------------------------------------------------------------------------------------
        self.mainloop()

if __name__ == "__main__":
    app = RungeKuttaApp()